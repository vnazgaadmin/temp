--------------------------------------------------------------------------------
| GLYPE PROXY
--------------------------------------------------------------------------------
| Theme: Simple
| Author: Glype
| Website: http://www.glype.com/
--------------------------------------------------------------------------------
| ABOUT
--------------------------------------------------------------------------------
 This is an example theme designed as a base for your own custom themes. 
 
 If you intend to distribute your theme, please read the guidelines for distributing
 themes in the documentation.
--------------------------------------------------------------------------------
| ADDITIONAL INFORMATION
--------------------------------------------------------------------------------
 If you require further help with your glype proxy, try the documentation or the
 forums over at http://www.glype.com/